package main.java.enuns;

public enum CoresEnum {
	
	VERMELHO,
	PRETO,
	BRANCO,
	AZUL,
}